const icon = (
	<svg
		xmlns="http://www.w3.org/2000/svg"
		width="20"
		height="20"
		viewBox="0 0 20 20"
	>
		<path
			d="M3 4.5v-2s3.34-1 7-1 7 1 7 1v2l-5 7.030v6.97s-1.22-0.090-2.25-0.59-1.75-1.41-1.75-1.41v-4.97z"
			fill="#f53d3d"
		/>
	</svg>
);

export default icon;
