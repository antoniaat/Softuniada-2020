const icon = <svg xmlns="http://www.w3.org/2000/svg" id="Capa_1" viewBox="0 0 60 60"
                  width="20" height="20">
    <path d="M0,0v60h60V0H0z M51,32H9v-4h42V32z" fill="#f63d3d" />
</svg>;

export default icon;