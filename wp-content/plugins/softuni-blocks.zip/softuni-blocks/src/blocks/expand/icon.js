const icon = (
	<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20">
		<path fill="#f63d3d" d="M5 6l5 5 5-5 2 1-7 7-7-7z" />
	</svg>
);

export default icon;
